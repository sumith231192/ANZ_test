package stepDefinition;

import io.cucumber.core.api.Scenario;
import io.cucumber.java.Before;



public class Hooks {
	public static Scenario scenario =null;
	
	@Before
	public void beforeSenarion(Scenario scen)
	{
		scenario = scen;
	}

}

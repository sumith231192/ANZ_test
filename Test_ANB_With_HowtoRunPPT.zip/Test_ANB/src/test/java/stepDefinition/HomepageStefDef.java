package stepDefinition;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pageObject.AmzHomePage;
import utility.ConfigFileReader;
import utility.DriverManager;
import utility.Helper;

public class HomepageStefDef {

	private WebDriver driver = DriverManager.getInstace().getDriver();
	private AmzHomePage amzHomePage = new AmzHomePage(driver);
	private ConfigFileReader conred = new ConfigFileReader();
	private Helper helper = new Helper();

	@Given("User is in ANZ borrow page")
	public void user_is_in_ANZ_borrow_page() {
		amzHomePage.naviagetToUrl(conred.getApplicationUrl());
		Hooks.scenario.write("Log in Sucessfull");
		Helper.takeSnapShot(Hooks.scenario, driver);
	}

	@Given("User select the applcation type as {string}")
	public void user_select_the_applcation_type_as(String string) {
		amzHomePage.setApplicationType(string);
		Hooks.scenario.write("Applcation type " + string + "selected");
		Helper.takeSnapShot(Hooks.scenario, driver);
		
	}

	@Given("User select the number of dependance as {string}")
	public void user_select_the_number_of_dependance_as(String string) {
		amzHomePage.setNumberOfDependance(string);
		Hooks.scenario.write("Dep  " + string + " set");
		Helper.takeSnapShot(Hooks.scenario, driver);
		
	}

	@Given("User select the property to buy as {string}")
	public void user_select_the_propert_to_buy_as(String string) {
		amzHomePage.setBorrwType(string);
		Hooks.scenario.write("Property to buy  " + string + " set");
		Helper.takeSnapShot(Hooks.scenario, driver);
		
	}

	@Then("User fills the income as {string} and other income as {string}")
	public void user_fills_the_income_as_and_other_income_as(String IncomeBeforeTax, String othericome) {
		amzHomePage.setIncomeBeforeTax(IncomeBeforeTax);
		amzHomePage.setOtherIncome(othericome);
		Hooks.scenario.write("Property to buy  " + IncomeBeforeTax + " set");
		Helper.takeSnapShot(Hooks.scenario, driver);
		
	}

	@Then("User fills the living expenses as {string}")
	public void user_fills_the_living_expenses_as(String string) {
		amzHomePage.setLivingExp(string);
		Hooks.scenario.write("living expenses   " + string + " set");
		Helper.takeSnapShot(Hooks.scenario, driver);
		
	}
	@Then("User fills the other commitments as {string}")
	public void user_fills_OtherCommit(String string) {
		amzHomePage.setOthercommitments(string);;
		Hooks.scenario.write("living expenses   " + string + " set");
		Helper.takeSnapShot(Hooks.scenario, driver);
		
	}

	@Then("User fills the current home loan repayments as {string} and other loan repayments as {string}")
	public void user_fills_the_current_home_loan_repayments_as_and_other_loan_repayments_as(String homeLoan,
			String otherLoan) {
		amzHomePage.setHomeloans(homeLoan);
		amzHomePage.setOtherloans(otherLoan);
		Hooks.scenario.write("homeLoan   " + homeLoan + " set");
		Hooks.scenario.write("otherLoan   " + otherLoan + " set");
		Helper.takeSnapShot(Hooks.scenario, driver);
	}

	@Then("User fills the  total credit card limits as {string}")
	public void user_fills_the_total_credit_card_limits_as(String string) {
		amzHomePage.setCredit(string);
		Hooks.scenario.write("credit card limits as   " + string + " set");
		Helper.takeSnapShot(Hooks.scenario, driver);
	}

	@Then("User cliks on Work out how much I could borrow button")
	public void user_cliks_onWorkouthowmuchIcouldborrow_button() {
		amzHomePage.clickHowmuchBorrow();
		Helper.takeSnapShot(Hooks.scenario, driver);

	}
	
	@Then("User ushould be able to see warning message {string} for the Living expenses")
	public void user_ValidateWarning(String msg) {
		amzHomePage.validateWarningLivingExp(msg);
		Helper.takeSnapShot(Hooks.scenario, driver);

	}

	@Then("User validate the amount as {string}")
	public void user_ValidateAmount(String amnt) {
		String actamnt =amzHomePage.validate_amountBorrow(amnt);
		Hooks.scenario.write("ValidateAmount Expected: " + amnt + "Actual in Application: "+actamnt);
		Helper.takeSnapShot(Hooks.scenario, driver);
	}
	
	@Then("User clicks on StartOver Button")
	public void user_ClickStartOver() {
		amzHomePage.clickStartOver();
		Helper.takeSnapShot(Hooks.scenario, driver);
	}
	
	@Then("User validate the message as {string}")
	public void user_ValidateMsg(String msg) {
		amzHomePage.vaidateMsgAs(msg);
		Hooks.scenario.write("Validatemsg as   " + msg + " ");
		Helper.takeSnapShot(Hooks.scenario, driver);
	}

}

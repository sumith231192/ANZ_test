package pageObject;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import utility.ConfigFileReader;
import utility.WaitUtil;

public class AmzHomePage {
	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	WaitUtil waitUtil = new WaitUtil();

	public AmzHomePage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//label[@for='application_type_single']")
	private WebElement single;
	@FindBy(xpath = "//label[@for='application_type_joint']")
	private WebElement joint;
	@FindBy(xpath = "//select[@title='Number of dependants']")
	private WebElement numDep;
	@FindBy(xpath = "//input[@id='borrow_type_home']//parent::label")
	private WebElement borrow_type_home;
	@FindBy(xpath = "//input[@id='borrow_type_investment']//parent::label")
	private WebElement borrow_type_investment;
	@FindBy(xpath = "//span[@id='q2q1i1']/ancestor::div[@class='input__wrapper']/input")
	private WebElement icomeBeforeTax;
	@FindBy(xpath = "//span[@id='q2q2i1']/ancestor::div[@class='input__wrapper']/input")
	private WebElement otherIncome;
	@FindBy(xpath = "//input[@id ='expenses']")
	private WebElement expenses;
	@FindBy(xpath = "//input[@id ='homeloans']")
	private WebElement homeloans;
	@FindBy(xpath = "//input[@id ='otherloans']")
	private WebElement otherloans;
	@FindBy(xpath = "//span[@id='q3q4i1']/ancestor::div[@class='input__wrapper']/input")
	private WebElement othercommitments;
	@FindBy(xpath = "//input[@id ='credit']")
	private WebElement credit;
	@FindBy(xpath = "//button[@id='btnBorrowCalculater']")
	private WebElement btnBorrowCalculater;
	@FindBy(xpath = "//span[@id='borrowResultTextAmount']")
	private WebElement borrwResult;
	@FindBy(xpath =  "//button[@class='start-over']")
	private WebElement startOver;
	@FindBy(xpath =  "//span[@class='borrow__error__text']")
	private WebElement validateMsgAs;
	@FindBy(xpath = "//label[@id='q3q1']/ancestor::div[@class='borrow__question']//div[@class='input__wrapper']//span[@id='required']")
	private WebElement livingExpWarning;
	
	public void naviagetToUrl(String url) {
		driver.get(url);
		waitUtil.sleepSeconds(3);
	}

	public void setApplicationType(String value) {
		if (value.equalsIgnoreCase("Single")) {
			waitUtil.untilWebElementVisible(driver, single);
			single.click();
		} else if (value.equalsIgnoreCase("Joint")) {
			waitUtil.untilWebElementVisible(driver, joint);
			joint.click();
			
		}

	}

	public void setNumberOfDependance(String depCount) {
		Select select = new Select(numDep);
		select.selectByVisibleText(depCount);
	}

	public void setBorrwType(String value) {
		if (value.equalsIgnoreCase("Home to live in")) {
			waitUtil.untilWebElementVisible(driver, borrow_type_home);
			borrow_type_home.click();
			borrow_type_home.click();
			waitUtil.sleepSeconds(1);
		} else if (value.equalsIgnoreCase("Residential investment")) {
			waitUtil.untilWebElementVisible(driver, borrow_type_investment);
			borrow_type_investment.click();
		}

	}

	public void setIncomeBeforeTax(String income) {

		icomeBeforeTax.sendKeys(income);
	}

	public void setOtherIncome(String income) {

		otherIncome.sendKeys(income);
	}

	public void setLivingExp(String income) {

		expenses.sendKeys(income);
	}

	public void setHomeloans(String income) {

		homeloans.sendKeys(income);
	}

	public void setOtherloans(String income) {

		otherloans.sendKeys(income);
	}

	public void setOthercommitments(String income) {

		othercommitments.sendKeys(income);
	}

	public void setCredit(String income) {

		credit.sendKeys(income);
	}

	public void setBorrowCalculater(String income) {

		btnBorrowCalculater.sendKeys(income);
	}
	
	public void clickHowmuchBorrow() {
		waitUtil.untilWebElementIsClickable(driver, borrow_type_home);
		btnBorrowCalculater.click();
		waitUtil.untilPageLoadComplete(driver);
		waitUtil.sleepSeconds(3);
	}
	
	public String validate_amountBorrow(String amnt)
	{
		waitUtil.untilPageLoadComplete(driver);
		waitUtil.untilWebElementVisible(driver, borrwResult);
		assertEquals(borrwResult.getText().trim().equals(amnt.trim()), true);
		return borrwResult.getText().trim();
		
	}
	
	public void clickStartOver()
	{
		startOver.click();
		waitUtil.sleepSeconds(2);
	}
	public void vaidateMsgAs(String msg)
	{
		assertEquals(validateMsgAs.getText().trim().equals(msg.trim()), true);
	}
	
	public void validateWarningLivingExp(String msg)
	{
		assertEquals(livingExpWarning.getText().trim().equals(msg.trim()), true);
	}
}

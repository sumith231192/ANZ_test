package utility;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverManager {
	private ConfigFileReader configFileReader = new ConfigFileReader();
	private WebDriver driver;
	private static DriverManager instance;
	private WaitUtil waitUtil = new WaitUtil();

	public WebDriver getDriver() {
		if (driver == null) {

			driver = createDriver();

		}

		return driver;
	}

	public static DriverManager getInstace() {
		if (instance == null) {
			instance = new DriverManager();
		}
		return instance;
	}

	private WebDriver createDriver() {
		driver = createLocalDriver();
		return driver;
	}

	private WebDriver createRemoteDriver() {
		throw new RuntimeException("RemoteWebDriver is not yet implemented");
	}


	/*rivate WebDriver createLocalDriver() {
		Reporter.log("Initializing Browser.....");
		String browser = configFileReader.getBrowser();
		Reporter.log(browser);
		if ("CHROME".equalsIgnoreCase(browser.toUpperCase())) {
			String driverpath = configFileReader.getChromeDriverPath();		
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//drivers//chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();

		} else if ("IE".equalsIgnoreCase(browser.toUpperCase())) {
			System.setProperty("webdriver.ie.driver", "./src/main/resources/drivers/IEDriver.exe");
			DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();

			ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			ieCapabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);

			ieCapabilities.setCapability("ie.ensureCleanSession", true);

			driver = new InternetExplorerDriver(ieCapabilities);
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();

		}
		return driver;
	}
*/
	
	private WebDriver createLocalDriver() {
		/* goo */
		killDriver();
		System.out.println("Browser Lauch");
		String browser = "CHROME";
		// Reporter.log(browser);
		if ("CHROME".equalsIgnoreCase(browser)) {

			WebDriverManager.chromedriver().setup();
			this.driver = new ChromeDriver();
			this.driver.manage().window().maximize();
			this.driver.manage().deleteAllCookies();

		} else if ("IE".equalsIgnoreCase(browser.toUpperCase())) {

			WebDriverManager.iedriver().setup();
			this.driver = new InternetExplorerDriver();
			this.driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			this.driver.manage().window().maximize();
			this.driver.manage().deleteAllCookies();

		}

		else if ("firefox".equalsIgnoreCase(browser.toUpperCase())) {
			WebDriverManager.firefoxdriver().setup();
			this.driver = new FirefoxDriver();
			this.driver.manage().window().maximize();
			this.driver.manage().deleteAllCookies();
		}

		return this.driver;
	}
	public void quitDriver() {
		driver.manage().deleteAllCookies();
		driver.quit();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	public void killDriver()

	{
		try {
			Runtime.getRuntime().exec("cmd");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Runtime.getRuntime().exec("taskkill /F /IM chrome.exe /T");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		waitUtil.sleepSeconds(2);
	}

	public void closeDriver() {
		driver.manage().deleteAllCookies();
		driver.close();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

}
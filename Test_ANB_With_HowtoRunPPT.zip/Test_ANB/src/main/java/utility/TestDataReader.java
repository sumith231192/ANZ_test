package utility;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class TestDataReader {

	private Properties properties = new Properties();
	private final String propertyFilePath = "./src/main/resources/TestData/";
//	private final String propertyFileWriterPath = "./src/main/resources/TestData/TestDataTC.properties";
	
	String fileName;
	

	public TestDataReader(String PropertyfileName) {
		BufferedReader reader;
		fileName=PropertyfileName;
		try {
			reader = new BufferedReader(new FileReader(propertyFilePath+fileName+".properties"));
			properties = new Properties();
			try {
				properties.load(reader);
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("Configuration.properties not found at " + propertyFilePath);
		}
	}

	public Map<String, String> getDataFromTestData() {
		BufferedReader reader;
		Properties properties = new Properties();
		HashMap<String, String> mymap = new HashMap<String, String>();
		try {
			reader = new BufferedReader(new FileReader(propertyFilePath+fileName+".properties"));
			properties = new Properties();
			try {
				properties.load(reader);
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("Configuration.properties not found at " + propertyFilePath);
		}
		
		for (String key : properties.stringPropertyNames()) {
			String value = properties.getProperty(key);
			mymap.put(key, value);
		}

		return mymap;

	}
	
public void  setTestDataforTCProperties(String key, String value)  {
	FileOutputStream out;
	FileInputStream input;
	Properties properties = new Properties();
	
		if (key != null)
			try {
				if(value != null)
				{
				input = new FileInputStream(propertyFilePath+fileName+".properties");
				properties.load(input);
				input.close();
				out = new FileOutputStream(propertyFilePath+fileName+".properties");
				properties.setProperty(key, value);
				properties.store(out, null);
				out.close();
				}
				
			} catch (IOException e) {
				
			} finally {
				
			}
		else
			throw new RuntimeException("driverPath not specified in the Configuration.properties file.");
	}

}

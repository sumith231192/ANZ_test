package utility;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;


import io.cucumber.core.api.Scenario;

public class Helper {
//	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	WaitUtil waitUtil = new WaitUtil();

		
	public static void takeSnapShot(Scenario scen,WebDriver driver) 
	{
		scen.embed(((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES), "image/png");
	}
	
	
}
